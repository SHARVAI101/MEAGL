<!DOCTYPE html>
<html>
<body>

<?php
<h1>Css</body>h1>
?> 

</body>
</html>