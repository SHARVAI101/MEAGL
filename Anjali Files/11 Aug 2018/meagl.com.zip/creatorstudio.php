<?php
include 'top.php';
include 'leftnav.php';


?>

<div class="creatorstudio-infobox"><br>
	<i class="fas fa-cog" style="height:20px;width:20px;margin-left:18px;color:#1967d2"></i><h1 style="font-size:28px;display:inline;color:#1967d2"> Creator Studio</h1>
	<hr style="border-color:#cccccc;margin-top:20px">
		
		<div class="subscribers-infobox"><br>

			<h1 style="font-size:23px;margin-left:10px;color:#3c4043;display:inline">  Subscribers<p id="more-info-chevron-subscribers" style="cursor:pointer;margin-top:-23px;margin-left:260px">
   			<span class="glyphicon glyphicon-chevron-down"></span></p></h1>
   				<hr style="border-color:#cccccc;margin-top:5px">


   			<a href="#" style="text-align:center;margin-left:80px;font-size:20px;margin-top:300px"><img style="position:absolute;left:35px;height:35px;width:35px;border-radius:50%" src="defaults/anjali.jpg">Anjali</a><br><br><br>
    		<a href="#" style="text-align:center;margin-left:80px;font-size:20px"><img style="position:absolute;left:35px;height:35px;width:35px;border-radius:50%" src="defaults/sharvai.jpg">Sharvai</a>
   		</div>
			
   		<div class="donations-infobox">
   			<i class="fas fa-hand-holding-usd" style="height:20px;width:20px;margin-left:10px;margin-top:15px;color:#1967d2"></i><h1 style="font-size:23px;display:inline;margin-left:10px;color:#1967d2;margin-top:50px">Donations</h1><br>
			<hr style="border-color:#cccccc;margin-top:23px"><br>

				<h1 class="donations-info" style="position:absolute">Total Donations :</h1>
				<h1 class="donations-info" style="margin-left:400px">Money Earned :</h1><br><br>

				<h1 class="donations-info" style="margin-left:240px">DONATORS <p id="more-info-chevron-donator" style="margin-top:-20px"><span class="glyphicon glyphicon-chevron-down"></span></p></h1><br>
					<a href="#" style="text-align:center;margin-left:310px;font-size:20px;margin-top:300px"><img style="position:absolute;left:270px;height:35px;width:35px;border-radius:50%" src="defaults/anjali.jpg">Anjali</a><br><br><br>
    				<a href="#" style="text-align:center;margin-left:310px;font-size:20px"><img style="position:absolute;left:270px;height:35px;width:35px;border-radius:50%" src="defaults/sharvai.jpg">Sharvai</a><br><br><br>

				<h1 class="donations-info" style="margin-left:200px">Top Donor of all Time :</h1><br>			


		<svg style="position: relative;display: inline;" class="svg-inline--fa fa-check-circle fa-w-16" aria-hidden="true" data-prefix="fas" data-icon="check-circle" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">

				


		<svg style="position: relative;display: inline;" class="svg-inline--fa fa-check-circle fa-w-16" aria-hidden="true" data-prefix="fas" data-icon="check-circle" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
			
		</svg>
	</div>
</div>