 <!DOCTYPE html>
<html>
<head>
	<title>MEAGL</title>
	<link rel="icon" type="image/png" href="logo/m_gold.png"></link>
	<link rel="stylesheet" href="Frontend/global.css"></link>
</head>
<body>

	<img src="logo/m_gold.png" class="develop-logo centering" style="margin-left:auto;margin-right:auto;display:block;left:0">
	<p class="develop-text" style="font-size:18px;width:300px;margin:20px auto 0 auto;display:block"><a href="m.meagl.com">Go to the mobile website!</a></p>

</body>
</html> 