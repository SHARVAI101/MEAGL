<?php
include 'top.php';
?>

<div class="card" style="padding-top:100px"><br>
  
  <h1 style="margin-top:-100px">Tipping Yedya!</h1>
 
  
  <div style="margin: 24px 0;">
    <p style="text-align:center;margin-left:10px;font-size:23px;margin-top:30px;color:#b225a8">
      <img style="position:absolute;left:160px;height:200px;width:190px;border-radius:50%" src="defaults/sharvai.jpg"><br><br><br><br><br><br><br><b>Anjali Sharvai Patil</b><br><br></p>
    <a href="#" style="color:grey;font-size:22px;font-family:arial;letter-spacing:2px">Elon Musk Inspirational</a><br><br><br>
    
    <p class="tip-amount" style="display:inline;font-size:20px;color:black;letter-spacing:1px">Tip amount: </p><input type="text" name="email" class="tip-amount"><br><br><br>
    <button type="submit" class="tipbutton"><h3 style="font-size:22px;margin-top:7px">Tip</button><br> 
    
 </div>
</div>

