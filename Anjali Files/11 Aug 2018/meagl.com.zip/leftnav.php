<!-- Side navigation -->

<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: "Lato", sans-serif;
}


@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
    .sidenav a {font-size: 18px;}
}



</style>
</head>
<body>
	<div class="sidenav" style="padding-top:80px">
  		<a href="#" style="text-align: center">Username</a><br>
  		
 		
 		<button type="submit" class="creatorstudio-btn"><h3 style="font-size:22px;margin-top:7px">Creator Studio</button><br>
 		
		<a href="#"><h2 style="font-size:20px"><i class="fas fa-upload"></i> Upload Meme</h2></a><br>
		
  		<a href="#"><h2 style="font-size:20px"><i class="fab fa-quora"></i> Meme Developers' Forum</h2></a>
  		<hr style="border-color:#e3e4e5">
  		<a href="#" class="sidebar-heading" style="font-size:20px"><h2 style="font-size:20px"> MEME CATEGORIES</h2></a>

  		
  		<div class="dropdown-content" style="display:none">
    		<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25;width:25;border-radius:50%" src="defaults/savage.png"> Savage</a>
    		<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/sports.png"> Sports</a>
    		<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/celeb.png"> Celeb</a>
			<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/gaming.png"> Gaming</a>
			<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/comic.png"> Comic</a>
			<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/college.png"> College/School</a>
			<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/politics.png"> Politics</a>
			<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/justmythoughts.png"> Just my thoughts</a>
			<a href="#" class="dropdown-menu-item" style="text-align:left;margin-left:40px"><img style="position:absolute;left:35px;height:25px;width:25px;border-radius:50%" src="defaults/other.png"> Other</a>
		</div>

 		<p id="more-info-chevron" style="cursor:pointer">
   		<span class="glyphicon glyphicon-chevron-down"></span></p>
   		<hr style="border-color:#e3e4e5">

  		<a href="#" class="sidebar-heading" style="font-size:20px">SUBSCRIPTIONS</a>
  		<p id="more-info-chevron-sub" style="cursor:pointer">
   		<span class="glyphicon glyphicon-chevron-down"></span></p>
  		<hr style="border-color:#e3e4e5">

		<a href="#"><h2 style="font-size:20px;padding-top:0px"><i class="fab fa-whatsapp"></i> Contact Us</h2></a><br>
	</div>
	